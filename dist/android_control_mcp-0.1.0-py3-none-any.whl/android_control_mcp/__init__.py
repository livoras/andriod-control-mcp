"""Android Control MCP - MCP server for Android device control"""

__version__ = "0.1.0"

from .server import mcp

__all__ = ["mcp"]